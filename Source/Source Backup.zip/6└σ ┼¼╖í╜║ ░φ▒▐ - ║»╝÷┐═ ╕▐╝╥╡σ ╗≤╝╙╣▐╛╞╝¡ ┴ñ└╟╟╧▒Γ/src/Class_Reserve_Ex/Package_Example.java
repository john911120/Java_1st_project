package Class_Reserve_Ex;

public class Package_Example {

	public void testPackage() {
		System.out.println("Package_Example");
	}

	public static void main(String[] args) {
		
	}

}
